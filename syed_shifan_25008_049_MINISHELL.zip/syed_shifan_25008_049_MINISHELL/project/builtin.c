#include<stdio.h>

char *builtins[] = {"echo", "printf", "read", "cd", "pwd", "pushd", "popd", "dirs", "let", "eval",
						"set", "unset", "export", "declare", "typeset", "readonly", "getopts", "source", "exit",
						 "exec", "shopt", "caller", "true", "type", "hash", "bind", "help","jobs", "fg", "bg", NULL};